<?php
	include("functions/verifica_link.php")
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="css/estilo.css" rel="stylesheet">
	
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Pacifico&family=Pathway+Gothic+One&display=swap" rel="stylesheet"> 
	<title>DOCE SABOR - Para adoçar o seu dia</title>
</head>
<body>
	<header>
		<div class="img_topo"></div>
		<!-- <img src="images/topo_doce_sabor.jpg" alt="Doce Sabor" width="100%" /> -->
		
