
	
	<!-- Corpo do site -->

		<div id="principal-e">
			<div class="contatos">

				<h1>Entre em contato conosco</h1>
				<p><img src="images/fone_icon.png" width="50" style="float: left; vertical-align: middle;" /> <strong>Telefone:</strong> (61) 99999-9999</p>
		
				<br />
				<br />

				<h2>Se preferir, utilize o formulário abaixo:</h2>
				
				<form action="pages/dados_form.php" method="post">
					<p><strong>Nome:</strong> <input type="text" name="nome" /></p>
					<p><strong>E-Mail:</strong> <input type="text" name="email" /></p>
					<p><strong>Mensagem:</strong></p>
					<p>
						<textarea name="mensagem" id="mensagem" cols="35" rows="4"></textarea>
					</p>

					<input type="submit" value="Enviar" />
				</form>				

				
			</div>
			<div style="text-align: center;">
				<img src="images/img_contato.png" width="350" />
				<br />
			</div>

		</div>
		<br />		
		<br />		

