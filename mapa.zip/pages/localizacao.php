
	<!-- Corpo do site -->
	
	<div id="principal-e">
		<h1>localização</h1>	
	
		<div id="shadow">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3838.4334963456686!2d-47.95755748580493!3d-15.833797589026727!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x935a3029eaad68b7%3A0xc4985755bc8593cc!2sParkShopping%20-%20Bras%C3%ADlia!5e0!3m2!1spt-BR!2sbr!4v1629395798006!5m2!1spt-BR!2sbr" width="1000" height="450" style="border:0;" allowfullscreen="" loading="lazy">
				
			</iframe>
		</div>	
	</div>
	<br />
	<br />
