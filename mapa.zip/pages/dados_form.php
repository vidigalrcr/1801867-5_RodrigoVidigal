<?php
	$nome = $_POST["nome"];
	$email = $_POST["email"];
	$mensagem = $_POST["mensagem"];
	
	echo "Recebendo seus dados<br />Nome: $nome <br /> E-Mail: $email <br />Mensagem: $mensagem";
?>