	</main>
	
	<!-- Rodapé do site -->
	
	<div class="h-line">
			
	</div>
	<footer>
				
		<div class="rodape">
			
			<div>
				<img src="images/logo_ds.png" width="200" alt="" />
			</div>			
				
			<div>
				<p><?= $rodape["info"]; ?></p>
			</div>			

		</div>

	</footer>
	
</body>
</html>	