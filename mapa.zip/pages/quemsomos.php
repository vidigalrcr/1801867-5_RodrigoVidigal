
	<!-- Corpo do site -->
	
	
	
	<div id="principal-e">
		<h1><?= $quemsomos["titulo"]; ?></h1>	
	

		<img src="images/img_loja.jpg" alt="loja" width="40%" class="img-site">

		<p><?= $quemsomos["info"]; ?></p>
		
	</div>
	<br />
	<br />
